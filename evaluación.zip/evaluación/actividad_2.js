const express = require("express");
const app = express();
const port = 2500;
//declaro un arreglo de objetos
let electrodomensticos = [
    { tipo: "plancha", origen: "China", precio: 5000, Stock: 200 },
    { tipo: "licuadora", origen: "USA", precio: 10000, Stock: 70 },
    { tipo: "tostadora", origen: "Argentina", precio: 15000, Stock: 60 },
    { tipo: "aspiradora", origen: "Peru", precio: 50000, Stock: 50 },
    { tipo: "coputadora", origen: "Japon", precio: 75000, Stock: 300 },
    { tipo: "labarropa", origen: "Australia", precio: 35000, Stock: 20 },
    { tipo: "freidora", origen: "Canada", precio: 25000, Stock: 100 },
];
//imprimo el arreglo de objetos
app.get("/", (req, res) => {
    res.send(
        "el electrodomestico es una: " +
            electrodomensticos[0].tipo +
            ", es de origen: " +
            electrodomensticos[0].origen +
            ", el precio es: " +
            electrodomensticos[0].precio +
            ", el Stock del pruducto es: " +
            electrodomensticos[0].Stock
    );
});
//compruebo que la actividad corre de forma correcta en el pueto 2500
app.listen(port, () => {
    console.log(`actividad dos corriendo en el puerto: ${port}`);
});
